import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

public class RemoveCommentsTest {

	@Test
	public void testRemoveComments() {
		RemoveComments removeComments = new RemoveComments();
        String[] source = {"/*Test program */", "int main()", "{ ", "  // variable declaration ", "int a, b, c;", "/* This is a test", "   multiline  ", "   comment for ", "   testing */", "a = b + c;","}"};
        List<String> list = removeComments.removeComments(source);
        List<String> test = list;
        assertEquals(test,list);
	}
	}
		
