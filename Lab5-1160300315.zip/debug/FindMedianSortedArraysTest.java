import static org.junit.Assert.*;

import org.junit.Test;

public class FindMedianSortedArraysTest {

	@Test
	public void test1() {
		int[] nums1 = {1,3};
		int[] nums2 = {2};
		FindMedianSortedArrays f = new FindMedianSortedArrays();
		assertEquals(2.0,f.findMedianSortedArrays(nums1,nums2),0.01);
	}
	
	@Test
	public void test2() {
		int[] nums1 = {1,2};
		int[] nums2 = {3,4};
		FindMedianSortedArrays f = new FindMedianSortedArrays();
		assertEquals(2.5,f.findMedianSortedArrays(nums1,nums2),0.01);
	}
	
	@Test
	public void test3() {
		int[] nums1 = {1,1,1};
		int[] nums2 = {5,6,7};
		FindMedianSortedArrays f = new FindMedianSortedArrays();
		assertEquals(3.0,f.findMedianSortedArrays(nums1,nums2),0.01);
	}
	
	@Test
	public void test4() {
		int[] nums1 = {1,1};
		int[] nums2 = {1,2,3};
		FindMedianSortedArrays f = new FindMedianSortedArrays();
		assertEquals(1.0,f.findMedianSortedArrays(nums1,nums2),0.01);
	}
}
