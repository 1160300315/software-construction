package circularOrbit;

import centralObject.CentralObject;
import physicalObject.PhysicalObject;
import track.Track;

import java.util.*;

/**
 * Calculate and store the difference of two circular orbit systems
 */
public class Difference {
	private int trackSizeDifference;
	private final Map<Integer, Integer> quantityDifference = new HashMap<>();
	private final Map<Integer, Set<PhysicalObject>> positiveObjectDifference = new HashMap<>();
	private final Map<Integer, Set<PhysicalObject>> negativeObjectDifference = new HashMap<>();
	
	public Difference() {}
	
	public Difference getDifference(CircularOrbit c1, CircularOrbit c2) {
		objectDifference(c1, c2);
		return this;
	}
	
	public int getTrackSizeDifference() { return trackSizeDifference; }
	
	public Map<Integer, Integer> getQuantityDifference() { return quantityDifference; }
	
	public Map<Integer, Set<PhysicalObject>> getPositiveObjectDifference() { return positiveObjectDifference; }
	
	public Map<Integer, Set<PhysicalObject>> getNegativeObjectDifference() { return negativeObjectDifference; }
	
	/**
	 * Get the difference of objects on every track
	 *
	 * @param c1 circular orbit system 1
	 * @param c2 circular orbit system 2
	 */
	private void objectDifference(CircularOrbit<CentralObject, PhysicalObject> c1,
	                              CircularOrbit<CentralObject, PhysicalObject> c2) {
		List<Track> tracks1 = c1.getTracks();
		List<Track> tracks2 = c2.getTracks();
		int sizeOfTracks1 = tracks1.size();
		int sizeOfTracks2 = tracks2.size();
		trackSizeDifference = sizeOfTracks1 - sizeOfTracks2;
		System.out.println("杞ㄩ亾鏁板樊寮傦細" + (sizeOfTracks1 - sizeOfTracks2));
		if (sizeOfTracks1 >= sizeOfTracks2) {
			for (int i = 0; i < sizeOfTracks2; i++) {
				quantityDifference.put(i + 1,
				                       (c1.getPhysicalObjectsOnTrack(tracks1.get(i)).size() -
						                       c2.getPhysicalObjectsOnTrack(
								                       tracks2.get(i)).size()));
				Set<PhysicalObject> objects1 = new HashSet<>();
				Set<PhysicalObject> objects2 = new HashSet<>();
				for (PhysicalObject physicalObject1: c1.getPhysicalObjectsOnTrack(
						tracks1.get(i))) {
					if (!c2.getPhysicalObjectsOnTrack(tracks2.get(i)).contains(physicalObject1)) {
						objects1.add(physicalObject1);
					}
					positiveObjectDifference.put(i + 1, objects1);
				}
				for (PhysicalObject physicalObject2: c2.getPhysicalObjectsOnTrack(
						tracks2.get(i))) {
					if (!c1.getPhysicalObjectsOnTrack(tracks1.get(i)).contains(physicalObject2)) {
						objects2.add(physicalObject2);
					}
					negativeObjectDifference.put(i + 1, objects2);
				}
				if (objects1.isEmpty() && objects2.isEmpty()) {
					System.out.println("杞ㄩ亾" + (i + 1) + "鐗╀綋宸紓锛�" + "鏃�");
				} else {
					System.out.println(
							"杞ㄩ亾" + (i + 1) + "鐗╀綋宸紓锛�" + "{" + objects1 + "}" + "{" + objects2 +
									"}");
				}
			}
			for (int i = sizeOfTracks2; i < sizeOfTracks1; i++) {
				quantityDifference.put(i + 1,
				                       (c1.getPhysicalObjectsOnTrack(tracks1.get(i)).size() -
						                       c2.getPhysicalObjectsOnTrack(
								                       tracks2.get(i)).size()));
				Set<PhysicalObject> objects1 = new HashSet<>();
				Set<PhysicalObject> objects2 = new HashSet<>();
				for (PhysicalObject physicalObject1: c1.getPhysicalObjectsOnTrack(
						tracks1.get(i))) {
					if (!c2.getPhysicalObjectsOnTrack(tracks2.get(i)).contains(physicalObject1)) {
						objects1.add(physicalObject1);
					}
					positiveObjectDifference.put(i + 1, objects1);
				}
				negativeObjectDifference.put(i + 1, objects2);
				if (objects1.isEmpty() && objects2.isEmpty()) {
					System.out.println("杞ㄩ亾" + (i + 1) + "鐗╀綋宸紓锛�" + "鏃�");
				} else {
					System.out.println(
							"杞ㄩ亾" + (i + 1) + "鐗╀綋宸紓锛�" + "{" + objects1 + "}" + "{" + objects2 +
									"}");
				}
			}
		} else {
			for (int i = 0; i < sizeOfTracks1; i++) {
				quantityDifference.put(i + 1,
				                       (c1.getPhysicalObjectsOnTrack(tracks1.get(i)).size() -
						                       c2.getPhysicalObjectsOnTrack(
								                       tracks2.get(i)).size()));
				Set<PhysicalObject> objects1 = new HashSet<>();
				Set<PhysicalObject> objects2 = new HashSet<>();
				for (PhysicalObject physicalObject1: c1.getPhysicalObjectsOnTrack(
						tracks1.get(i))) {
					if (!c2.getPhysicalObjectsOnTrack(tracks2.get(i)).contains(physicalObject1)) {
						objects1.add(physicalObject1);
					}
					positiveObjectDifference.put(i + 1, objects1);
				}
				for (PhysicalObject physicalObject2: c2.getPhysicalObjectsOnTrack(
						tracks2.get(i))) {
					if (!c1.getPhysicalObjectsOnTrack(tracks1.get(i)).contains(physicalObject2)) {
						objects2.add(physicalObject2);
					}
					negativeObjectDifference.put(i + 1, objects2);
				}
				if (objects1.isEmpty() && objects2.isEmpty()) {
					System.out.println("杞ㄩ亾" + (i + 1) + "鐗╀綋宸紓锛�" + "鏃�");
				} else {
					System.out.println(
							"杞ㄩ亾" + (i + 1) + "鐗╀綋宸紓锛�" + "{" + objects1 + "}" + "{" + objects2 +
									"}");
				}
			}
			for (int i = sizeOfTracks1; i < sizeOfTracks2; i++) {
				quantityDifference.put(i + 1,
				                       (c1.getPhysicalObjectsOnTrack(tracks1.get(i)).size() -
						                       c2.getPhysicalObjectsOnTrack(
								                       tracks2.get(i)).size()));
				Set<PhysicalObject> objects1 = new HashSet<>();
				Set<PhysicalObject> objects2 = new HashSet<>();
				positiveObjectDifference.put(i + 1, objects1);
				for (PhysicalObject physicalObject2: c2.getPhysicalObjectsOnTrack(
						tracks2.get(i))) {
					if (!c1.getPhysicalObjectsOnTrack(tracks1.get(i)).contains(physicalObject2)) {
						objects2.add(physicalObject2);
					}
					negativeObjectDifference.put(i + 1, objects2);
				}
				if (objects1.isEmpty() && objects2.isEmpty()) {
					System.out.println("杞ㄩ亾" + (i + 1) + "鐗╀綋宸紓锛�" + "鏃�");
				} else {
					System.out.println(
							"杞ㄩ亾" + (i + 1) + "鐗╀綋宸紓锛�" + "{" + objects1 + "}" + "{" + objects2 +
									"}");
				}
			}
		}
	}
}