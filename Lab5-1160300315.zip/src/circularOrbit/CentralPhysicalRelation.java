package circularOrbit;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Control relation between central object and a physical object
 *
 * @param <L> CentralObject
 * @param <E> PhysicalObject
 */
public class CentralPhysicalRelation<L, E> implements Relation<L, E> {
	private Map<L, Set<E>> centralPhysicalRelation = new HashMap<>();
	
	@Override public boolean addRelation(L centralObject, E physicalObject) {
		if (physicalObject == null) {
			centralPhysicalRelation.put(centralObject, new HashSet<>());
			return true;
		} else if (!centralPhysicalRelation.containsKey(centralObject)) {
			return false;
		} else {
			return centralPhysicalRelation.get(centralObject).add(physicalObject);
		}
	}
	@Override
	public boolean removeRelation(L centralObject, E physicalObject) {
		if (!centralPhysicalRelation.containsKey(centralObject)) {
			return false;
		} else {
			return centralPhysicalRelation.get(centralObject).remove(physicalObject);
		}
	}
	@Override
	public boolean hasRelation(L centralObject, E physicalObject) {
		return centralPhysicalRelation.containsKey(centralObject) &&
				centralPhysicalRelation.get(centralObject).contains(physicalObject);
	}
	
	public Set<E> getRelatedObjects(L centralObject) {
		return centralPhysicalRelation.get(centralObject);
	}
}