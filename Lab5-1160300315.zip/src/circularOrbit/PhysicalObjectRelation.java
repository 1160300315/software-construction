package circularOrbit;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Control relations between two physical objects
 *
 * @param <E> PhysicalObject
 */
class PhysicalObjectRelation<E> {
	private Map<E, Set<E>> positivePhysicalObjectRelation = new HashMap<>();
	private Map<E, Set<E>> negativePhysicalObjectRelation = new HashMap<>();
	
	boolean addRelation(E physicalObject1, E physicalObject2) {
		if (physicalObject2 == null) {
			negativePhysicalObjectRelation.put(physicalObject1, new HashSet<>());
			return true;
		} else if (physicalObject1 == null) {
			positivePhysicalObjectRelation.put(physicalObject2, new HashSet<>());
			return true;
		}
		if (!negativePhysicalObjectRelation.containsKey(physicalObject1) ||
				!positivePhysicalObjectRelation.containsKey(physicalObject2)) {
			return false;
		} else
		{
			return negativePhysicalObjectRelation.get(physicalObject1).add(physicalObject2) &&
					positivePhysicalObjectRelation.get(physicalObject2).add(physicalObject1);
		}
			
	}
	
	boolean removeRelation(E physicalObject1, E physicalObject2) {
		if (!negativePhysicalObjectRelation.containsKey(physicalObject1) ||
				!positivePhysicalObjectRelation.containsKey(physicalObject2)) {
			return false;
		} else
		{
			return negativePhysicalObjectRelation.get(physicalObject1).remove(physicalObject2) &&
					positivePhysicalObjectRelation.get(physicalObject2).remove(physicalObject1);
		}
			
	}
	
	boolean hasRelation(E physicalObject1, E physicalObject2) {
		return negativePhysicalObjectRelation.containsKey(physicalObject1) &&
				positivePhysicalObjectRelation.containsKey(physicalObject2) &&
				negativePhysicalObjectRelation.get(physicalObject1).contains(physicalObject2) &&
				positivePhysicalObjectRelation.get(physicalObject2).contains(physicalObject1);
	}
	
	Set<E> getRelatedObjects(E physicalObject) {
		Set<E> relatedObjects = getPositiveObjects(physicalObject);
		relatedObjects.addAll(getNegativeObjects(physicalObject));
		return relatedObjects;
	}
	
	void removeObject(E physicalObject) {
		positivePhysicalObjectRelation.remove(physicalObject);
		negativePhysicalObjectRelation.remove(physicalObject);
	}
	
	private Set<E> getNegativeObjects(E physicalObject) {
		return negativePhysicalObjectRelation.get(physicalObject);
	}
	
	private Set<E> getPositiveObjects(E physicalObject) {
		return positivePhysicalObjectRelation.get(physicalObject);
	}
}