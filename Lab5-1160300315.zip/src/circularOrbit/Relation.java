package circularOrbit;

/**
 * Control the relations with objects
 */
interface Relation<L,E> {
	/**
	 * Add relations between object_1 and object_2
	 *
	 * @param object_1 first object
	 * @param object_2 second object
	 * @return if there is not object_1, return false
	 */
	boolean addRelation(L object1, E object2);
	
	/**
	 * Remove relations between object_1 and object_2
	 *
	 * @param object_1 first object
	 * @param object_2 second object
	 * @return if there is not object_1 or object_2, return false
	 */
	boolean removeRelation(L object1, E object2);
	
	/**
	 * Determine if there is a relation between two objects
	 *
	 * @param object_1 first object
	 * @param object_2 second object
	 * @return if there is a relation between two objects, return true, else return false
	 */
	boolean hasRelation(L object1, E object2);
}