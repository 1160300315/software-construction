package test.applications;

import applications.AtomStructure;
import centralObject.Core;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * AtomStructure Tester.
 *
 * @author <1170300603>
 * @version 1.0
 * @since <pre</pre> //something wrong due to encoding problem.
 */
public class AtomStructureTest {
	/**
	 * Method: buildAtomStructureFromFile(String fileName)
	 */
	@Test public void testBuildTracksFromFile() throws Exception {
		AtomStructure atomStructure =
				new AtomStructure().buildAtomStructureFromFile("test/AtomicStructure_Medium.txt");
		assertEquals("the core's name should be \"Rb\"", "Er",
		             atomStructure.getCentralObject().getLabel());
		assertEquals("the number of track should be 6", 6, atomStructure.getTracks().size());
		assertEquals("the number of electronic should be 68", 68,
		             atomStructure.getPhysicalObjects().size());
	}
	
	/**
	 * Method: transit(Electronic electronic, Track target)
	 */
	@Test public void testTransit() throws Exception{
		AtomStructure atomStructure =
				new AtomStructure().buildAtomStructureFromFile("test/AtomicStructure_Medium.txt");
		//assertEquals("the electronic_1 is on track_1",);
		
	}
	@Test public void testAtomStructure() {
	}
	@Test public void testbuildAtomStructure() {
	}
	@Test public void testbuildcore() {
		Core core = new Core();
	}
}