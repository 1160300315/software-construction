package test.circularOrbit;

import applications.StellarSystem;
import centralObject.Stellar;
import circularOrbit.CircularOrbitHelper;
import circularOrbit.ConcreteCircularOrbit;
import org.junit.Test;
import physicalObject.Planet;

/**
 * CircularOrbitHelper Tester.
 *
 * @author <1170300603>
 * @version 1.0
 * @since <pre>4月 12, 2019</pre>
 */
public class CircularOrbitHelperTest {
	
	/**
	 * Method: visualize(CircularOrbit c)
	 */
	@Test public void testVisualize() throws Exception {
//		ConcreteCircularOrbit<Stellar, Planet> stellarSystem =
//				new StellarSystem().buildStellarSystemFromFile("test/StellarSystem.txt");
//		CircularOrbitHelper circularOrbitHelper = new CircularOrbitHelper();
//		circularOrbitHelper.visualize(stellarSystem);
	}
}