package test.circularOrbit;

import centralObject.CentralObject;
import centralObject.Stellar;
import circularOrbit.CircularOrbit;
import circularOrbit.ConcreteCircularOrbit;
import exceptions.OrderException;
import physicalObject.PhysicalObject;
import physicalObject.Planet;
import track.Track;
import java.util.Collections;
import org.junit.Test;
import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * ConcreteCircularOrbit Tester.
 *
 * @author <1170300603>
 * @version 1.0
 * @since <pre>April 9, 2019</pre>
 */
public class ConcreteCircularOrbitTest extends CircularOrbitInstanceTest {
	//Use Stellar as central object and Planet as the physical object
	@Override public CircularOrbit<CentralObject, PhysicalObject> emptyInstance() {
		return new ConcreteCircularOrbit<>();
	}
	
	/**
	 * Method: setCentralObject(L centralObject)
	 * @throws OrderException 
	 */
	@Test public void testSetCentralObject() throws OrderException {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Stellar central = new Stellar();
		circularOrbitInstance.setCentralObject(central);
		assertEquals("Central object's label should be \"default\"", "default",
		             circularOrbitInstance.getCentralObject().getLabel());
		Stellar newCentral = new Stellar("Sun", 0, 0);
		circularOrbitInstance.setCentralObject(newCentral);
		assertEquals("Central object's label should be \"Sun\"", "Sun",
		             circularOrbitInstance.getCentralObject().getLabel());
	}
	
	/**
	 * Method: addTrack(Track track)
	 */
	@Test public void testAddTrack() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		assertEquals("No track", Collections.EMPTY_LIST, circularOrbitInstance.getTracks());
		Track track1 = new Track("track", 1);
		circularOrbitInstance.addTrack(track1);
		assertEquals("There is one track", 1, circularOrbitInstance.getTracks().size());
		assertEquals("The size of orbit objects should be 0", 0,
		             circularOrbitInstance.getPhysicalObjects().size());
		Track track2 = new Track("track", 2);
		circularOrbitInstance.addTrack(track2);
		assertEquals("There is 2 tracks", 2, circularOrbitInstance.getTracks().size());
	}
	
	/**
	 * Method: removeTrack()(Track track)
	 */
	@Test public void testReduceTrack() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track1 = new Track("track", 1);
		circularOrbitInstance.addTrack(track1);
		assertEquals("There is one track", 1, circularOrbitInstance.getTracks().size());
		Track track2 = new Track("track", 1);
		circularOrbitInstance.removeTrack(track2);
		assertEquals("No track", Collections.EMPTY_LIST, circularOrbitInstance.getTracks());
	}
	
	/**
	 * A complex situation to test the correctness
	 * @throws OrderException 
	 */
	@Test public void testReduceTrackWithObjects() throws OrderException {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track1 = new Track("track_1", 1);
		Track track2 = new Track("track_2", 2);
		Track track3 = new Track("track_3", 3);
		Track track4 = new Track("track_4", 4);
		Track track5 = new Track("track_5", 5);
		circularOrbitInstance.addTrack(track1);
		circularOrbitInstance.addTrack(track2);
		circularOrbitInstance.addTrack(track3);
		circularOrbitInstance.addTrack(track4);
		assertEquals("the size of tracks should be 4", 4,
		             circularOrbitInstance.getTracks().size());
		Planet object1 = new Planet();
		Planet object2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object4 = new Planet("Earth_3", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		circularOrbitInstance.addObject(track1, object1);
		circularOrbitInstance.addObject(track2, object2);
		circularOrbitInstance.addObject(track3, object3);
		circularOrbitInstance.addObject(track4, object4);
		assertEquals("the size of orbit objects should be 4", 4,
		             circularOrbitInstance.getPhysicalObjects().size());
		Stellar stellar = new Stellar("Sun", 7.2e5, 2e30);
		circularOrbitInstance.setCentralObject(stellar);
		circularOrbitInstance.addRelationOfCentralPhysical(object1);
		circularOrbitInstance.addRelationOfCentralPhysical(object2);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object2);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object3);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object4);
		circularOrbitInstance.addRelationOfPhysicalObject(object2, object4);
		assertTrue("Sun has relation with object_1", circularOrbitInstance.hasRelation(object1));
		assertTrue("successfully remove track_1", circularOrbitInstance.removeTrack(track1));
		assertFalse("fail to remove track_5", circularOrbitInstance.removeTrack(track5));
		assertEquals("the size of physical objects should be 3", 3,
		             circularOrbitInstance.getPhysicalObjects().size());
		assertFalse("central object has no relation with object_1",
		            circularOrbitInstance.hasRelation(object1));
		assertFalse("object_1 does not have related physical objects",
		            circularOrbitInstance.hasRelation(object1, object2) ||
				            circularOrbitInstance.hasRelation(object1, object3) ||
				            circularOrbitInstance.hasRelation(object1, object4));
	}
	
	/**
	 * Method: addObject(Track target, E physicalObject)
	 */
	@Test public void testAddObject() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track1 = new Track("track_1", 1);
		Track track2 = new Track("track_2", 2);
		Track track3 = new Track("track_3", 3);
		Track track4 = new Track("track_4", 4);
		Track track5 = new Track("track_5", 5);
		circularOrbitInstance.addTrack(track1);
		circularOrbitInstance.addTrack(track2);
		circularOrbitInstance.addTrack(track3);
		circularOrbitInstance.addTrack(track4);
		Planet object1 = new Planet();
		Planet object2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object4 = new Planet("Earth_3", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		circularOrbitInstance.addObject(track1, object1);
		circularOrbitInstance.addObject(track2, object2);
		circularOrbitInstance.addObject(track3, object3);
		circularOrbitInstance.addObject(track4, object4);
		assertEquals("The size of orbit objects should be 4", 4,
		             circularOrbitInstance.getPhysicalObjects().size());
		assertFalse("can't add a object to a track that do not exist",
		            circularOrbitInstance.addObject(track5, object1));
	}
	
	/**
	 * Method removeObject(E physicalObject)
	 * @throws OrderException 
	 */
	@Test public void testRemoveObject() throws OrderException {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track1 = new Track("track_1", 1);
		Track track2 = new Track("track_2", 2);
		Track track3 = new Track("track_3", 3);
		Track track4 = new Track("track_4", 4);
		circularOrbitInstance.addTrack(track1);
		circularOrbitInstance.addTrack(track2);
		circularOrbitInstance.addTrack(track3);
		circularOrbitInstance.addTrack(track4);
		assertEquals("the size of tracks should be 4", 4,
		             circularOrbitInstance.getTracks().size());
		Planet object1 = new Planet();
		Planet object2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object4 = new Planet("Earth_3", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object5 = new Planet("Earth_4", "solid", "blue", 1.27e4, 1.5e9, 40, "CW", 0);
		circularOrbitInstance.addObject(track1, object1);
		circularOrbitInstance.addObject(track2, object2);
		circularOrbitInstance.addObject(track3, object3);
		circularOrbitInstance.addObject(track4, object4);
		assertEquals("the size of orbit objects should be 4", 4,
		             circularOrbitInstance.getPhysicalObjects().size());
		Stellar stellar = new Stellar("Sun", 7.2e5, 2e30);
		circularOrbitInstance.setCentralObject(stellar);
		circularOrbitInstance.addRelationOfCentralPhysical(object1);
		circularOrbitInstance.addRelationOfCentralPhysical(object2);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object2);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object3);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object4);
		circularOrbitInstance.addRelationOfPhysicalObject(object2, object4);
		assertTrue("successfully remove object_1", circularOrbitInstance.removeObject(object1));
		assertFalse("fail to remove object_5", circularOrbitInstance.removeObject(object5));
		assertEquals("the size of physical objects should be 3", 3,
		             circularOrbitInstance.getPhysicalObjects().size());
		assertFalse("central object has no relation with object_1",
		            circularOrbitInstance.hasRelation(object1));
		assertFalse("object_1 does not have related physical objects",
		            circularOrbitInstance.hasRelation(object1, object2) ||
				            circularOrbitInstance.hasRelation(object1, object3) ||
				            circularOrbitInstance.hasRelation(object1, object4));
		assertFalse("object_1 does not have related track",
		            circularOrbitInstance.hasRelation(object1, track1));
	}
	
	/**
	 * Method: addRelationOfCentralPhysical(L centralObject, E physicalObject)
	 * @throws OrderException 
	 */
	@Test public void addRelationOfCentralPhysical() throws OrderException {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track1 = new Track("track_1", 1);
		Track track2 = new Track("track_2", 2);
		Track track3 = new Track("track_3", 3);
		Track track4 = new Track("track_4", 4);
		Track track5 = new Track("track_5", 5);
		circularOrbitInstance.addTrack(track1);
		circularOrbitInstance.addTrack(track2);
		circularOrbitInstance.addTrack(track3);
		circularOrbitInstance.addTrack(track4);
		assertEquals("the size of tracks should be 4", 4,
		             circularOrbitInstance.getTracks().size());
		Planet object1 = new Planet();
		Planet object2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object4 = new Planet("Earth_3", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		circularOrbitInstance.addObject(track1, object1);
		circularOrbitInstance.addObject(track2, object2);
		circularOrbitInstance.addObject(track3, object3);
		circularOrbitInstance.addObject(track4, object4);
		assertEquals("the size of orbit objects should be 4", 4,
		             circularOrbitInstance.getPhysicalObjects().size());
		Stellar stellar = new Stellar("Sun", 7.2e5, 2e30);
		circularOrbitInstance.setCentralObject(stellar);
		circularOrbitInstance.addRelationOfCentralPhysical(object1);
		circularOrbitInstance.addRelationOfCentralPhysical(object2);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object2);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object3);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object4);
		circularOrbitInstance.addRelationOfPhysicalObject(object2, object4);
		assertTrue("Sun has relation with object_1", circularOrbitInstance.hasRelation(object1));
		assertTrue("Sun has relation with object_1",
		           circularOrbitInstance.getRelatedPhysicalObjects().contains(object1));
	}
	
	/**
	 * Method: addRelationOfPhysicalObject(E physicalObject_1, E physicalObject_2)
	 * @throws OrderException 
	 */
	@Test public void addRelationOfPhysicalObject() throws OrderException {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track1 = new Track("track_1", 1);
		Track track2 = new Track("track_2", 2);
		Track track3 = new Track("track_3", 3);
		Track track4 = new Track("track_4", 4);
		Track track5 = new Track("track_5", 5);
		circularOrbitInstance.addTrack(track1);
		circularOrbitInstance.addTrack(track2);
		circularOrbitInstance.addTrack(track3);
		circularOrbitInstance.addTrack(track4);
		assertEquals("the size of tracks should be 4", 4,
		             circularOrbitInstance.getTracks().size());
		Planet object1 = new Planet();
		Planet object2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object4 = new Planet("Earth_3", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		circularOrbitInstance.addObject(track1, object1);
		circularOrbitInstance.addObject(track2, object2);
		circularOrbitInstance.addObject(track3, object3);
		circularOrbitInstance.addObject(track4, object4);
		assertEquals("the size of orbit objects should be 4", 4,
		             circularOrbitInstance.getPhysicalObjects().size());
		Stellar stellar = new Stellar("Sun", 7.2e5, 2e30);
		circularOrbitInstance.setCentralObject(stellar);
		circularOrbitInstance.addRelationOfCentralPhysical(object1);
		circularOrbitInstance.addRelationOfCentralPhysical(object2);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object2);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object3);
		circularOrbitInstance.addRelationOfPhysicalObject(object1, object4);
		circularOrbitInstance.addRelationOfPhysicalObject(object2, object4);
		assertTrue("object_1 has related physical objects",
		           circularOrbitInstance.hasRelation(object1, object2) &&
				           circularOrbitInstance.hasRelation(object1, object3) &&
				           circularOrbitInstance.hasRelation(object1, object4));
		assertTrue("successfully remove track_1", circularOrbitInstance.removeTrack(track1));
		assertEquals("the size of orbit objects should be 3", 3,
		             circularOrbitInstance.getPhysicalObjects().size());
		assertFalse("central object has no relation with object_1",
		            circularOrbitInstance.hasRelation(object1));
		assertFalse("object_1 does not have related physical objects",
		            circularOrbitInstance.hasRelation(object1, object2) ||
				            circularOrbitInstance.hasRelation(object1, object3) ||
				            circularOrbitInstance.hasRelation(object1, object4));
	}
	
	/**
	 * Method: transit(E physicalObject, Track track)
	 */
	@Test public void testTransit() {
		CircularOrbit<CentralObject, PhysicalObject> circularOrbitInstance = emptyInstance();
		Track track1 = new Track("track_1", 1);
		Track track2 = new Track("track_2", 2);
		circularOrbitInstance.addTrack(track1);
		circularOrbitInstance.addTrack(track2);
		Planet object1 = new Planet();
		Planet object2 = new Planet("Earth_1", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		Planet object3 = new Planet("Earth_2", "solid", "blue", 1.27e4, 1.5e9, 30, "CW", 0);
		circularOrbitInstance.addObject(track1, object1);
		circularOrbitInstance.addObject(track2, object2);
		assertEquals("the size of physical objects should be 2", 2,
		             circularOrbitInstance.getPhysicalObjects().size());
		circularOrbitInstance.transit(object1, track2);
		assertEquals("track_2 has object_1", track2,
		             circularOrbitInstance.getTrackOfObject(object1));
		assertFalse("track_1 has not relation with object_1",
		            circularOrbitInstance.hasRelation(object1, track1));
		assertFalse("Can't transit object does not exist",
		            circularOrbitInstance.transit(object3, track1));
	}
}