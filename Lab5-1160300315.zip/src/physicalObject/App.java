package physicalObject;

public class App implements PhysicalObject {
	private final String name;
	private final String corporation;
	private final String version;
	private final String feature;
	private final String businessArea;
	private final double azimuth;
	
	private void checkRep() {
		assert this.name != null;
		assert this.corporation != null;
		assert this.version != null;
		assert this.feature != null;
		assert this.businessArea != null;
		assert azimuth >= 0 && azimuth <= 360;
	}
	
	public App() {
		this.name = "default";
		this.corporation = "default";
		this.version = "default";
		this.feature = "default";
		this.businessArea = "default";
		this.azimuth = 0;
	}
	
	public App(String name, String corporation, String version, String feature,
	           String businessArea,
	           double azimuth) {
		this.name = name;
		this.corporation = corporation;
		this.version = version;
		this.feature = feature;
		this.businessArea = businessArea;
		this.azimuth = azimuth;
	}
	@Override
	public String getLabel() { return name; }
	
	public String getCorporation() { return corporation; }
	
	public String getVersion() { return version; }
	
	public String getFeature() { return feature; }
	
	public String getBusinessArea() { return businessArea; }
	
	@Override
	public double getAzimuth() { return azimuth; }
	
	@Override public boolean equals(PhysicalObject that) {
		if (!(that instanceof App))
			{return false;}
		App thatApp = (App) that;
		return this.getLabel().equals(thatApp.getLabel()) &&
				this.getCorporation().equals(thatApp.getCorporation()) &&
				this.getVersion().equals(thatApp.getVersion()) &&
				this.getFeature().equals(thatApp.getFeature()) &&
				this.getBusinessArea().equals(thatApp.getBusinessArea());
	}
	
	@Override public int hashCode() {
		return name.hashCode() ^ corporation.hashCode() ^ version.hashCode() ^ feature.hashCode() ^
				businessArea.hashCode();
	}
}