package exceptions;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ExceptionChecking {
	public ExceptionChecking() {}
	static public List<String> checkingExceptionType(String fileName,String label) {
		List<String> lineData = null;
		List<String> list = new ArrayList<String>();    
		try {
			lineData = new BufferedReader((new FileReader(fileName))).lines().collect(Collectors.toList());
		}catch(FileNotFoundException e){
			e.printStackTrace();
			System.out.println("The specified file is not present at the given path.");
		}
		String rgex = "<"+label+">(.*?)</"+label+">";  
		Pattern pattern = Pattern.compile(rgex);
		for(String line:lineData) {
			if (line!=null) {
				Matcher m = pattern.matcher(line);
				if (m.find()) {
					int i = 1;
					list.add(m.group(i));
					i++;
				}
			}
		}
		return list;
	}
}

