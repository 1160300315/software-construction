package exceptions;

public class UpperException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UpperException(String s) {
		super(s);
	}
}
