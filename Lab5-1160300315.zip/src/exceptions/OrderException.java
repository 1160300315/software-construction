package exceptions;

public class OrderException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public OrderException(String s) {
		super(s);
	}

}
