package exceptions;

public class DependenciesException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public DependenciesException(String s) {
		super(s);
	}

}
