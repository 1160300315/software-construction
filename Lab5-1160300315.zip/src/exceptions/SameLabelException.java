package exceptions;

public class SameLabelException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8031092188159151907L;

	
	public SameLabelException(String s) {
		super(s);
	}

}
