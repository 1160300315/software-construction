package exceptions;

public class ScientificException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ScientificException(String s) {
		super(s);
	}
}
