package exceptions;

public class NumberofdigitsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public NumberofdigitsException(String s) {
		super(s);
	}
	
}
