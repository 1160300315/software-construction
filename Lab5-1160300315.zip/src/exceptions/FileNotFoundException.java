package exceptions;

public class FileNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7875081039777223037L;
	
	public FileNotFoundException(String s) {
		super(s);
	}

}
