package exceptions;

public class SelfReferenceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public SelfReferenceException(String s) {
		super(s);
	}

}
