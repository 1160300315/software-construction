package exceptions;

public class RadiusException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1562429651109148361L;

	public RadiusException(String s) {
		super(s);
	}
}
