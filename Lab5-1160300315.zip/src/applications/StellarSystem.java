package applications;

import centralObject.Stellar;
import circularOrbit.ConcreteCircularOrbit;
import physicalObject.Planet;
import track.Track;
import exceptions.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.lang.Exception;

/**
 * Concrete Stellar System
 */
public class StellarSystem extends ConcreteCircularOrbit<Stellar, Planet> {
	//builder
	public StellarSystem() {}
	
	private void checkRep() {
		//every track has a planet
		for (Track track: getTracks()) {
			assert getPhysicalObjectsOnTrack(track).size() == 1;
		}
	}
	
	/**
	 * build the stellar system from the file
	 *
	 * @param fileName file name
	 * @return the new stellar system build by the file
	 * @throws NumberofdigitsException 
	 * @throws NumberException 
	 * @throws SameLabelException 
	 * @throws UpperException 
	 * @throws IOException 
	 * @throws SecurityException 
	 * @throws FileNotFoundException if file is not found
	 */
	private static Pattern pattern1 = Pattern.compile("([a-zA-Z]+)\\s::=");
	public StellarSystem buildStellarSystemFromFile(String fileName) throws NumberException, NumberofdigitsException, SameLabelException, UpperException, SecurityException, IOException  {
		List<String> lineData = null;
		Logger logger1 = Logger.getLogger("StellarBuildingLogger");
		FileHandler fileHandler = new FileHandler("D:\\Lab\\Lab4-1160300823\\log\\log.txt");
		try {
			lineData = new BufferedReader((new FileReader(fileName))).lines().collect(Collectors.toList());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			logger1.addHandler(fileHandler);
			logger1.severe(fileName+": fatal misktake in input file!");
			System.out.println("The specified file is not present at the given path.");
		}
		
		
			try {
				for (String line: lineData) {
					if (line != null) {
						Matcher matcher = pattern1.matcher(line);
						if (matcher.find()) {
							if (matcher.group(1).equals("Stellar")) {
								buildStellarSystem(lineData);
								checkRep();
								return this;
							}
							throw new OrderException("The input file is not in the right format.");
						}
					}
				}
			}catch(OrderException oe) {
				logger1.addHandler(fileHandler);
				logger1.severe(fileName+": fatal misktake in input file!");
				System.out.println("The Order of Input has something wrong.");
				oe.printStackTrace();	
			}catch(NumberofdigitsException ndE) {
				logger1.addHandler(fileHandler);
				logger1.severe(fileName+": fatal misktake in Number of digits!");
				System.out.println("The Number of digits has something wrong.");
				ndE.printStackTrace();
			}catch(UpperException uE) {
				logger1.addHandler(fileHandler);
				logger1.severe(fileName+": fatal misktake in upper rules!");
				System.out.println("The input doesn't obey the Upeer rules.");
				uE.printStackTrace();
			}finally {
				logger1.addHandler(fileHandler);
				logger1.warning(fileName+": check your input file!");
				System.out.println("Please check your input file!");
			}
		checkRep();
		return this;
	}
	
	/**
	 * get the azimuth by the given time
	 *
	 * @param planet a
	 * @param time   running time
	 * @return new azimuth
	 */
	public double move(Planet planet, double time) {
		if (!physicalObjects.contains(planet)) {
			return -1;
		}
			
		double oldValue = planet.getAzimuth();
		if (planet.getOrientation().equals("CW")) {
			return (oldValue + planet.getRevolutionSpeed() * time) % 360;
		} else {
			return (oldValue - planet.getRevolutionSpeed() * time) % 360 + 360;
		}
	}
	
	/**
	 * output the position with given time
	 *
	 * @param time given time
	 */
	public void getPosition(double time) {
		System.out.println("Position of Planets After " + time + " Time");
		System.out.printf("%-15s %-15s %-15s\n", "NAME", "ORBIT RADIUS", "AZIMUTH");
		for (Planet planet: physicalObjects) {
			System.out.printf("%-15s %-15.2e %-15.2f\n", planet.getLabel(),
			                  planet.getOrbitRadius(),
			                  move(planet, time));
		}
	}
	
	/**
	 * build the system by the data
	 *
	 * @param lineData standard data
	 * @throws NumberofdigitsException 
	 * @throws NumberException 
	 * @throws SameLabelException 
	 * @throws UpperException 
	 */
	private static Pattern pattern2 = Pattern.compile("([a-zA-Z]+)\\s::=\\s<([^<>]+)>");
	private void buildStellarSystem(List<String> lineData) throws OrderException, NumberException, NumberofdigitsException, SameLabelException, UpperException{
		
		for (String line: lineData) {
			if (line != null) {
				Matcher matcher = pattern2.matcher(line);
				if (matcher.find()) {
					if (matcher.group(1).equals("Stellar")) {
						buildStellar(matcher.group(2));
					} else if (matcher.group(1).equals("Planet")) {
						buildPlanet(matcher.group(2));
					}
					//throw new OrderException("The input file is not in the right format.");
				}
			}
		}
	}
	
	/**
	 * build a stellar from the data
	 *
	 * @param stellarData standard data
	 * @throws OrderException 
	 * @throws NumberFormatException 
	 */
	private void buildStellar(String stellarData) throws NumberFormatException, OrderException {
		String regex = "(\\w+)\\s?,\\s?([1-9]\\d{0,3}(.\\d+)?|[1-9](.\\d+)?(e\\d+)?)\\s?,\\s?" +
				"([1-9]\\d{0,3}(.\\d+)?|[1-9](.\\d+)?(e\\d+)?)";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(stellarData);
		if (matcher.find()) {
			setCentralObject(new Stellar(matcher.group(1), Double.parseDouble(matcher.group(2)),
			                             Double.parseDouble(matcher.group(6))));
		}else {
			throw new OrderException("The input file has something wrong.");
		}
	}
	
	/**
	 * build a planet from the data
	 *
	 * @param planetData standard data
	 * @throws OrderException 
	 */
	private void buildPlanet(String planetData) throws NumberException,NumberofdigitsException,UpperException,SameLabelException, OrderException{
		String regex =
				"(\\w+)\\s?,\\s?(\\w+)\\s?,\\s?(\\w+)\\s?,\\s?(\\d{0,4}(.\\d+)?|[1-9](.\\d+)?" +
						"(e\\d+)?)\\s?,\\s?(\\d{0,4}(.\\d+)?|[1-9]0?(.\\d+)?(e\\d+)?)\\s?,\\s?" +
						"(\\d{0,4}(.\\d+)?|[1-9](.\\d+)?(e\\d+)?)\\s?,\\s?(CC?W)\\s?,\\s?(360(" +
						".0+)?|3[0-5]\\d(.\\d+)?|[12]\\d{2}(.\\d+)?|[1-9]\\d(.\\d+)?|\\d(.\\d+)?)";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(planetData);
		if (matcher.find()) {
			Track track = new Track("Track", Double.parseDouble(matcher.group(8)));
			Planet planet = new Planet(matcher.group(1), matcher.group(2), matcher.group(3),
			                           Double.parseDouble(matcher.group(4)),
			                           Double.parseDouble(matcher.group(8)),
			                           Double.parseDouble(matcher.group(12)), matcher.group(16),
			                           Double.parseDouble(matcher.group(17)));
			addTrack(track);
			addObject(track, planet);
		}else {
			throw new OrderException("planet�Ĳ����д���");}
		
	}
}