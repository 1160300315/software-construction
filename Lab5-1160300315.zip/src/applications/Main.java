package applications;

import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;
import exceptions.ExceptionChecking;
import circularOrbit.CircularOrbitHelper;
import physicalObject.App;

public class Main {
	
	public static void main(String[] args) throws Exception {
		StellarSystem stellarSystem =
				new StellarSystem().buildStellarSystemFromFile("test/StellarSystem.txt");
		AtomStructure atomStructure =
				new AtomStructure().buildAtomStructureFromFile("test/AtomicStructure.txt");
		PersonalAppEcosystem personalAppEcosystem =
				new PersonalAppEcosystem().buildPersonalAppEcosystemFromFile(
						"test/PersonalAppEcosystem.txt");
		CircularOrbitHelper circularOrbitHelper = new CircularOrbitHelper();
		//circularOrbitHelper.visualize(stellarSystem);
		System.out.println(15 / 10);
		stellarSystem.getPosition(1498328);
		atomStructure.getCentralObject();
		App app1 =
				new App("App44", "BRHVEG", "v74-69-66", "ImonnsFcwTAs87oBvYdrLNqBc9K58ZMD8qpk4qWZ",
				        "Video", 0);
		App app2 = new App("App130", "BHPVC", "v20", "xh2TooROqBxjCPC8GsTT1YswMljtuc5rGHcj0arj",
		                    "Music", 0);
		System.out.println(
				personalAppEcosystem.getLogicalDistance(personalAppEcosystem, app1, app2));
		
		List list = ExceptionChecking.checkingExceptionType("D:\\\\Lab\\\\Lab4-1160300823\\\\log\\\\log.txt", "date");
		System.out.println(list);
		}
	}
