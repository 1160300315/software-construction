package applications;

import centralObject.Core;
import circularOrbit.ConcreteCircularOrbit;
import exceptions.NumberofdigitsException;
import exceptions.OrderException;
import exceptions.SameLabelException;
import exceptions.ScientificException;
import exceptions.SelfReferenceException;
import exceptions.UpperException;
import physicalObject.Electronic;
import track.Track;
import strategy.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Concrete Atom System
 */
public class AtomStructure extends ConcreteCircularOrbit<Core, Electronic> {
	
	private Strategy strategy = new ConcreteStrategyFile();
	private Context context = new Context(strategy);
	
	//builder
	public AtomStructure() {}
	Logger logger1 = Logger.getLogger("AtomBuildingLogger");
	/**
	 * build the stellar system from the file
	 *
	 * @param fileName file name
	 * @return the new atom system build by the file
	 * @throws ScientificException 
	 * @throws NumberofdigitsException 
	 * @throws SameLabelException 
	 * @throws OrderException 
	 * @throws NumberFormatException 
	 * @throws UpperException 
	 * @throws SelfReferenceException 
	 * @throws IOException 
	 * @throws SecurityException 
	 * @author 
	 */
	private static Pattern pattern1 = Pattern.compile("([a-zA-Z]+)\\s::=\\s(\\w+)");
	public AtomStructure buildAtomStructureFromFile(String fileName) throws NumberFormatException, OrderException, SameLabelException, NumberofdigitsException, ScientificException, SelfReferenceException, UpperException, SecurityException, IOException {
		int numberOfTracks = 0;
		FileHandler fileHandler = new FileHandler("D:\\\\Lab\\\\Lab4-1160300823\\\\log\\\\log.txt");
		List<String> lineData = context.read(fileName);
		
		
		for (String line: lineData) {
			if (line != null) {
				Matcher matcher = pattern1.matcher(line);
				if (matcher.find()) {
					if (matcher.group(1).equals("NumberOfTracks")) {
						numberOfTracks = Integer.parseInt(matcher.group(2));
						break;
					}
				}
				}else {
					throw new OrderException("The input file is not right.");
				
			}
		}
		for (String line: lineData) {
			if (line != null) {
				Matcher matcher = pattern1.matcher(line);
				if (matcher.find()) {
					if (matcher.group(1).equals("ElementName")) {
						buildAtomStructure(lineData, numberOfTracks);
						return this;
					}
					
				}
			}else {
				logger1.addHandler(fileHandler);
				logger1.severe(fileName+": fatal misktake in input file!");
				throw new OrderException("The input file is not right.");
				
			}
		}
		return this;
	}
	
	/**
	 * build the system by the data
	 *
	 * @param lineData standard data
	 * @throws UpperException 
	 * @throws SelfReferenceException 
	 * @throws IOException 
	 * @throws SecurityException 
	 */
	private static Pattern pattern2 = Pattern.compile("([a-zA-Z]+)\\s::=\\s([A-Z][a-z]?|[\\d;/]+)");
	private void buildAtomStructure(List<String> lineData, int numberOfTracks) throws OrderException,SameLabelException,NumberFormatException,NumberofdigitsException,ScientificException, SelfReferenceException, UpperException, SecurityException, IOException{
		FileHandler fileHandler = new FileHandler("D:\\\\Lab\\\\Lab4-1160300823\\\\log\\\\log.txt");
		
		for (String line: lineData) {
			if (line != null) {
				Matcher matcher = pattern2.matcher(line);
				if (matcher.find()) {
					if (matcher.group(1).equals("ElementName")) {
						buildCore(matcher.group(2));
					} else if (matcher.group(1).equals("NumberOfElectron")) {
						buildElectronic(numberOfTracks, matcher.group(2));
					}
				}
			}else {
				logger1.addHandler(fileHandler);
				logger1.severe("fatal misktake in input file!");
				throw new OrderException("The input file is not right.");
				
		}
		}
	}
	
	/**
	 * build a core from the data
	 *
	 * @param coreData the core
	 * @throws OrderException 
	 */
	private void buildCore(String coreData) throws OrderException {
		Core core = new Core(coreData);
		setCentralObject(core);
	}
	
	/**
	 * build a electronic from the data
	 *
	 * @param numberOfTracks number of the track
	 * @param trackData      standard data
	 */
	private void buildElectronic(int numberOfTracks, String trackData)throws SameLabelException,ScientificException,SelfReferenceException,UpperException{
		String[] args = trackData.split("[;/]");
		assert args.length == numberOfTracks * 2;
		for (int i = 0; i < 2 * numberOfTracks; i += 2) {
			Track track = new Track(Integer.toString(i / 2));
			addTrack(track);
			for (int j = 0; j < Integer.parseInt(args[i + 1]); j++) {
				Electronic electronic =
						new Electronic(Integer.toString(j + 1), new Random().nextDouble() % 360);
				addObject(track, electronic);
			}
		}
	}
}