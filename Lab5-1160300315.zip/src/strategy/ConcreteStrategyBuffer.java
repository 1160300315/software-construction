package strategy;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.stream.Collectors;

public class ConcreteStrategyBuffer implements Strategy {

	@Override
	public List<String> readFile(String filename) throws FileNotFoundException {
		List<String> lineData = new BufferedReader((new FileReader(filename))).lines().collect(Collectors.toList());
		return lineData;
		
	}

	

}
