package strategy;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ConcreteStrategyScanner implements Strategy {

	

	@Override
	public List<String> readFile(String filename) throws FileNotFoundException {
		File file = new File(filename);		
		Scanner in = new Scanner(file);
		List<String> lineData = new ArrayList();
		while (in.hasNextLine()) {
			lineData.add(in.nextLine());
		}
		
		return lineData;
	}

}
