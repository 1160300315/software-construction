package strategy;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

public interface Strategy {

	/**
     * ���Է���
	 * @throws FileNotFoundException 
	 * @throws IOException 
     */
    public List<String> readFile(String filename) throws FileNotFoundException, IOException;
}
