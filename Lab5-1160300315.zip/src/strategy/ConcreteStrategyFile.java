package strategy;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class ConcreteStrategyFile implements Strategy {

	private String filename;

	@Override
	public List<String> readFile(String filename) throws IOException {
	    this.filename = filename;
		List<String> LineData = new ArrayList<>();
	   
		LineData = Files.readAllLines(Paths.get(filename),StandardCharsets.UTF_8);
		return LineData;
	}

}
