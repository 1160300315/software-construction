package centralObject;

import applications.StellarSystem;
import circularOrbit.CircularOrbit;

/**
 * The center object of the stellar system
 */
public class Stellar implements CentralObject {
	private final String name;
	private final double radius;
	private final double mass;
	
	private void checkRep() {
		assert name != null;
		assert radius >= 0;
		assert mass >= 0;
	}
	
	public Stellar() {
		this.name = "default";
		this.radius = 0;
		this.mass = 0;
	}
	
	public Stellar(String name, double radius, double mass) {
		this.name = name;
		this.radius = radius;
		this.mass = mass;
		checkRep();
	}
	
	@Override
	public String getLabel() { return name; }
	
	public double getRadius() { return radius;}
	
	public double getMass() { return mass; }
	
	@Override
	public boolean equals(CentralObject that) {
		if (!(that instanceof Stellar)) {
			return false;
		}
			
		Stellar thatPlanet = (Stellar) that;
		return this.getLabel().equals(thatPlanet.getLabel()) &&
				this.getRadius() == thatPlanet.getRadius() &&
				this.getMass() == ((Stellar) that).getMass();
	}
	
	@Override public int hashCode() { return name.hashCode() ^ (int) radius ^ (int) mass; }
}